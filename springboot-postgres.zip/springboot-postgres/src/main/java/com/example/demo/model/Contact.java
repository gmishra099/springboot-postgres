package com.example.demo.model;


import javax.persistence.Entity;

import lombok.Builder;
import lombok.Data;

@Data
@Entity
@Builder
public class Contact {
	private int id;
	private String firstName;
	private String lastName;
	private String phone;
	

}
